package com.realweather.treephysics.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public class TreePhysicsConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.DoubleValue WIND_STRENGTH_MULTIPLIER;
    public static final ModConfigSpec.BooleanValue ENABLE_BRANCH_PHYSICS;
    public static final ModConfigSpec.IntValue MAX_ANIMATED_TREES;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.push("physics");

        WIND_STRENGTH_MULTIPLIER = builder
                .comment("Scales how hard wind pushes every tree. 1.0 = default strength.")
                .defineInRange("windStrengthMultiplier", 1.0, 0.0, 5.0);

        ENABLE_BRANCH_PHYSICS = builder
                .comment("If false, only the trunk sways and branches stay rigid relative to it. " +
                        "Cheap fallback for low-end GPUs (e.g. GTX 1650) with many trees on screen.")
                .define("enableBranchPhysics", true);

        MAX_ANIMATED_TREES = builder
                .comment("Reserved for a future render-distance LOD pass: trees beyond this count " +
                        "would fall back to a static pose instead of being simulated. Not yet wired " +
                        "up to a tree registry in v1 - exposed here so that's a config change, not a " +
                        "code change, once you add it.")
                .defineInRange("maxAnimatedTrees", 200, 0, 5000);

        builder.pop();
        SPEC = builder.build();
    }
}
