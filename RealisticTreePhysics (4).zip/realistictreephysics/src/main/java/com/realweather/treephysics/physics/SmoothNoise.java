package com.realweather.treephysics.physics;

/**
 * Minimal, dependency-free 3D value noise with smoothstep interpolation.
 * This is NOT a true Simplex/Perlin implementation - it's a compact
 * approximation that gives continuous, gently-varying wind without
 * pulling in an external noise library. Good enough for ambient wind;
 * swap in a real noise lib if you want finer control over gust shape.
 */
final class SmoothNoise {
    private SmoothNoise() {}

    private static double hash(double x, double y, double z) {
        double h = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
        return h - Math.floor(h);
    }

    static double sample(double x, double y, double z) {
        double xf = Math.floor(x), yf = Math.floor(y), zf = Math.floor(z);
        double tx = x - xf, ty = y - yf, tz = z - zf;

        double v000 = hash(xf, yf, zf);
        double v100 = hash(xf + 1, yf, zf);
        double v010 = hash(xf, yf + 1, zf);
        double v110 = hash(xf + 1, yf + 1, zf);
        double v001 = hash(xf, yf, zf + 1);
        double v101 = hash(xf + 1, yf, zf + 1);
        double v011 = hash(xf, yf + 1, zf + 1);
        double v111 = hash(xf + 1, yf + 1, zf + 1);

        double cx = smooth(tx), cy = smooth(ty), cz = smooth(tz);
        double x00 = lerp(v000, v100, cx);
        double x10 = lerp(v010, v110, cx);
        double x01 = lerp(v001, v101, cx);
        double x11 = lerp(v011, v111, cx);
        double y0 = lerp(x00, x10, cy);
        double y1 = lerp(x01, x11, cy);
        return (lerp(y0, y1, cz) * 2.0) - 1.0; // remap 0..1 -> -1..1
    }

    private static double smooth(double t) {
        return t * t * (3 - 2 * t);
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }
}
