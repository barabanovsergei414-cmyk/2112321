package com.realweather.treephysics.physics;

import com.realweather.treephysics.config.TreePhysicsConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

import java.util.Random;

/**
 * The full bone tree for one placed tree: a tapered trunk made of several
 * stacked segments, each sprouting 1-2 branches higher up, each branch
 * splitting into child twigs. Procedurally generated from a seed, so the
 * same world position always regrows the same shape.
 */
public class TreeSkeleton {
    public final TreeBone root;

    private TreeSkeleton(TreeBone root) {
        this.root = root;
    }

    public static TreeSkeleton generate(long seed) {
        Random rnd = new Random(seed);
        int trunkSegments = 5 + rnd.nextInt(3); // 5-7 segments

        TreeBone root = new TreeBone(1.1f, 0.35f, 0.30f, 0, 0,
                /*stiffness*/ 9.0f, /*damping*/ 3.5f, /*windDrag*/ 0.5f);
        TreeBone current = root;

        for (int i = 1; i < trunkSegments; i++) {
            float taper = 1f - (i / (float) trunkSegments) * 0.6f;
            TreeBone segment = new TreeBone(
                    1.0f, 0.32f * taper, 0.28f * taper,
                    (rnd.nextFloat() - 0.5f) * 0.05f, 0,
                    Math.max(2.0f, 8.0f - i * 0.6f), // higher up the trunk flexes a bit more easily
                    3.0f,
                    0.5f);
            current.children.add(segment);
            current = segment;

            if (i >= trunkSegments / 2) {
                int branchCount = 1 + rnd.nextInt(2);
                for (int b = 0; b < branchCount; b++) {
                    current.children.add(generateBranch(rnd, 2));
                }
            }
        }
        return new TreeSkeleton(root);
    }

    private static TreeBone generateBranch(Random rnd, int segmentsLeft) {
        float pitch = (float) Math.toRadians(35 + rnd.nextInt(30));
        float yaw = (float) (rnd.nextFloat() * Math.PI * 2);
        TreeBone branch = new TreeBone(
                0.6f + rnd.nextFloat() * 0.3f, 0.12f, 0.05f,
                pitch, yaw,
                /*stiffness*/ 4.0f, /*damping*/ 2.0f, /*windDrag*/ 0.9f);
        if (segmentsLeft > 0) {
            branch.children.add(generateBranch(rnd, segmentsLeft - 1));
        }
        return branch;
    }

    public void tickPhysics(Level level, BlockPos pos, float dt) {
        float[] wind = WindField.windAt(level, pos, level.getGameTime());
        float multiplier = TreePhysicsConfig.WIND_STRENGTH_MULTIPLIER.get().floatValue();
        float strength = wind[0] * multiplier;
        float dir = wind[1];
        float windAlong = (float) Math.cos(dir) * strength;
        float windAcross = (float) Math.sin(dir) * strength;

        boolean branchesEnabled = TreePhysicsConfig.ENABLE_BRANCH_PHYSICS.get();
        stepBone(root, windAlong, windAcross, 0, 0, dt, true, branchesEnabled);
    }

    private void stepBone(TreeBone bone, float windAlong, float windAcross,
                           float parentBendVel, float parentSwayVel, float dt,
                           boolean isTrunk, boolean branchesEnabled) {
        if (isTrunk || branchesEnabled) {
            SpringDamperPhysics.step(bone, windAlong, windAcross, parentBendVel, parentSwayVel, dt);
        }
        // When branch physics is disabled, non-trunk bones just stay at their rest pose
        // (cheap fallback for low-end GPUs / many trees on screen at once).
        for (TreeBone child : bone.children) {
            stepBone(child, windAlong, windAcross, bone.bendVel, bone.swayVel, dt, false, branchesEnabled);
        }
    }
}
