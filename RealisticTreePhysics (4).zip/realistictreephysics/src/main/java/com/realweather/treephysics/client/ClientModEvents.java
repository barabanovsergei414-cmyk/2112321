package com.realweather.treephysics.client;

import com.realweather.treephysics.TreePhysicsMod;
import com.realweather.treephysics.client.render.PhysicsTreeRenderer;
import com.realweather.treephysics.registry.ModBlockEntities;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid = TreePhysicsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.PHYSICS_TREE.get(), PhysicsTreeRenderer::new);
    }
}
